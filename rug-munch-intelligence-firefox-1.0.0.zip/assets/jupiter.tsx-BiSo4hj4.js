import{e as w,s as m}from"./shadowInject-C76mS66z.js";async function u(){var a;const t=w(window.location.href);if(!t)return;const o=await m(t);if(!o.success||!o.data||o.data.not_scanned)return;const{risk_score:e,token_symbol:d}=o.data;if(e==null||e<50)return;chrome.runtime.sendMessage({type:"UPDATE_BADGE",score:e});const i=document.getElementById("rms-swap-warning");i&&i.remove();const r=document.querySelector('button[class*="swap-btn"], button[class*="Swap"], .jupiter-swap button[type="submit"], button:not([disabled])');if(!r)return;const s=document.createElement("div");s.id="rms-swap-warning";const n=e>=75;s.style.cssText=`
    width: 100%; padding: 10px 14px; margin: 8px 0;
    background: ${n?"#FF475720":"#FF8C0020"};
    border: 1px solid ${n?"#FF4757":"#FF8C00"};
    border-radius: 8px; font-family: system-ui; font-size: 12px;
    color: ${n?"#FF4757":"#FF8C00"}; font-weight: 500;
  `;const l=n?"🚨":"⚠️";s.innerHTML=`
    ${l} <strong>Rug Munch Intelligence:</strong> $${d||"Unknown"} has a risk score of
    <strong>${e}/100</strong>.
    ${n?"This token shows critical rug indicators.":"Exercise caution with this swap."}
  `,(a=r.parentElement)==null||a.insertBefore(s,r)}u();let c=window.location.href;const g=new MutationObserver(()=>{var t;window.location.href!==c&&(c=window.location.href,(t=document.getElementById("rms-swap-warning"))==null||t.remove(),setTimeout(u,800))});g.observe(document.body,{childList:!0,subtree:!0});
