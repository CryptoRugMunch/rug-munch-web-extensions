import{e as m,s as g}from"./shadowInject-C76mS66z.js";const d="__rms_jupiter_injected";if(!window[d]){window[d]=!0;async function i(){var u;const t=m(window.location.href);if(!t)return;const s=await g(t);if(!s.success||!s.data||s.data.not_scanned)return;const{risk_score:e,token_symbol:w}=s.data;if(e==null||e<50)return;chrome.runtime.sendMessage({type:"UPDATE_BADGE",score:e});const c=document.getElementById("rms-swap-warning");c&&c.remove();const r=document.querySelector('button[class*="swap-btn"], button[class*="Swap"], .jupiter-swap button[type="submit"], button:not([disabled])');if(!r)return;const o=document.createElement("div");o.id="rms-swap-warning";const n=e>=75;o.style.cssText=`
    width: 100%; padding: 10px 14px; margin: 8px 0;
    background: ${n?"#FF475720":"#FF8C0020"};
    border: 1px solid ${n?"#FF4757":"#FF8C00"};
    border-radius: 8px; font-family: system-ui; font-size: 12px;
    color: ${n?"#FF4757":"#FF8C00"}; font-weight: 500;
  `;const l=n?"🚨":"⚠️";o.innerHTML=`
    ${l} <strong>Rug Munch Intelligence:</strong> $${w||"Unknown"} has a risk score of
    <strong>${e}/100</strong>.
    ${n?"This token shows critical rug indicators.":"Exercise caution with this swap."}
  `,(u=r.parentElement)==null||u.insertBefore(o,r)}i();let a=window.location.href;new MutationObserver(()=>{var t;window.location.href!==a&&(a=window.location.href,(t=document.getElementById("rms-swap-warning"))==null||t.remove(),setTimeout(i,800))}).observe(document.body,{childList:!0,subtree:!0})}
