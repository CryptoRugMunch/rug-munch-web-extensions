import{e as l,s as m}from"./shadowInject-B0LIp1zm.js";async function u(){var a;const t=l(window.location.href);if(!t)return;const o=await m(t);if(!o.success||!o.data||o.data.not_scanned)return;const{risk_score:n,token_symbol:d}=o.data;if(n==null||n<50)return;chrome.runtime.sendMessage({type:"UPDATE_BADGE",score:n});const i=document.getElementById("rms-swap-warning");i&&i.remove();const r=document.querySelector('button[class*="swap-btn"], button[class*="Swap"], .jupiter-swap button[type="submit"], button:not([disabled])');if(!r)return;const s=document.createElement("div");s.id="rms-swap-warning";const e=n>=75;s.style.cssText=`
    width: 100%; padding: 10px 14px; margin: 8px 0;
    background: ${e?"#FF475720":"#FF8C0020"};
    border: 1px solid ${e?"#FF4757":"#FF8C00"};
    border-radius: 8px; font-family: system-ui; font-size: 12px;
    color: ${e?"#FF4757":"#FF8C00"}; font-weight: 500;
  `;const w=e?"🚨":"⚠️";s.innerHTML=`
    ${w} <strong>Rug Munch Warning:</strong> $${d||"Unknown"} has a risk score of
    <strong>${n}/100</strong>.
    ${e?"This token shows critical rug indicators.":"Exercise caution with this swap."}
  `,(a=r.parentElement)==null||a.insertBefore(s,r)}u();let c=window.location.href;const g=new MutationObserver(()=>{var t;window.location.href!==c&&(c=window.location.href,(t=document.getElementById("rms-swap-warning"))==null||t.remove(),setTimeout(u,800))});g.observe(document.body,{childList:!0,subtree:!0});
