var l={exports:{}},n={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var d;function R(){if(d)return n;d=1;var r=Symbol.for("react.transitional.element"),x=Symbol.for("react.fragment");function s(F,t,e){var a=null;if(e!==void 0&&(a=""+e),t.key!==void 0&&(a=""+t.key),"key"in t){e={};for(var o in t)o!=="key"&&(e[o]=t[o])}else e=t;return t=e.ref,{$$typeof:r,type:F,key:a,ref:t!==void 0?t:null,props:e}}return n.Fragment=x,n.jsx=s,n.jsxs=s,n}var f;function E(){return f||(f=1,l.exports=R()),l.exports}var p=E();const u={bg:"#0B0714",bgCard:"#1a1025",gold:"#E7C55F",purple:"#7E4CFF",purpleLight:"#9B7AFF",cyan:"#5FDDE7",red:"#FF4757",green:"#2ED573",orange:"#FF8C00",textPrimary:"#FFFFFF",textSecondary:"#98979C",textMuted:"#5a5960",border:"#2a2035"},i={low:u.green,moderate:u.gold,high:u.orange,critical:u.red,unknown:u.textMuted};function k(r){return r==null?i.unknown:r>=75?i.critical:r>=50?i.high:r>=25?i.moderate:i.low}function C(r){return r==null?"Unknown":r>=75?"Critical":r>=50?"High":r>=25?"Moderate":"Low"}function v(r){return r==null?"❓":r>=75?"🔴":r>=50?"🟠":r>=25?"🟡":"🟢"}export{u as C,k as a,C as b,p as j,v as r};
