import{e as g,r as u}from"./api-Cy855S04.js";import{C as w,s as k,J as $,r as f,R as E,a as v}from"./scanToSpec-DWHCfErx.js";const C=w,n=new Map;function N(t,s,e,o){var m;if(n.has(t))return;const a=(o==null?void 0:o.position)||"float-right",x=(o==null?void 0:o.compact)??!1,r=document.createElement("div");r.id=`rms-card-${t}`,a==="float-right"?r.style.cssText=`
      position: fixed; top: 80px; right: 12px; z-index: 999999;
      max-height: calc(100vh - 100px); overflow-y: auto;
      scrollbar-width: thin;
    `:a==="float-left"?r.style.cssText=`
      position: fixed; top: 80px; left: 12px; z-index: 999999;
      max-height: calc(100vh - 100px); overflow-y: auto;
      scrollbar-width: thin;
    `:r.style.cssText="display: block; margin: 8px 0;";const i=r.attachShadow({mode:"closed"}),l=document.createElement("style");l.textContent=`
    :host { all: initial; display: block; font-family: system-ui, -apple-system, sans-serif; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    ::-webkit-scrollbar { width: 4px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 2px; }

    @keyframes rms-fadein {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .rms-card-wrapper {
      animation: rms-fadein 0.3s ease-out;
    }
  `,i.appendChild(l);const c=document.createElement("div");c.className="rms-card-wrapper",i.appendChild(c);const d=document.createElement("div");c.appendChild(d),a==="after"?(m=s.parentElement)==null||m.insertBefore(r,s.nextSibling):document.body.appendChild(r);const y=x?v(e):k(e,{showActions:!0,showBreakdown:!0}),p=g.createRoot(d),b={share_result:()=>{const h=`${e.risk_score!=null?`Risk: ${e.risk_score}/100`:""} $${e.token_symbol||"?"}
Price: ${e.price_usd?`$${e.price_usd}`:"—"} | Liq: ${e.liquidity_usd?`$${e.liquidity_usd.toLocaleString()}`:"—"}
Scanned by Rug Munch Intelligence 🗿 https://t.me/rug_munchy_bot`;navigator.clipboard.writeText(h)},copy_address:()=>navigator.clipboard.writeText(e.token_address),open_explorer:()=>{const _=(e.chain||"solana")==="solana"?`https://solscan.io/token/${e.token_address}`:`https://etherscan.io/token/${e.token_address}`;window.open(_,"_blank")},full_scan:()=>{try{chrome.runtime.sendMessage({type:"OPEN_SIDE_PANEL"})}catch{}},open_chat:()=>{try{chrome.runtime.sendMessage({type:"OPEN_SIDE_PANEL"})}catch{}}};p.render(u.createElement($,{registry:f,handlers:b,initialState:{},children:u.createElement(E,{spec:y,registry:f})})),n.set(t,{root:p,host:r})}function S(t){const s=n.get(t);s&&(s.root.unmount(),s.host.remove(),n.delete(t))}function R(){for(const[t]of n)S(t)}export{N as i,R as r};
