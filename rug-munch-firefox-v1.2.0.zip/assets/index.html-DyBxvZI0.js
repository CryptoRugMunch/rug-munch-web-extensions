import{_ as D,c as E,C as t,r as O,b as N}from"./analytics-BXriFITw.js";import{j as i}from"./jsx-runtime-D_zvdyIk.js";import{e as H,r as m,s as U}from"./api-Cy855S04.js";import{e as K}from"./shadowInject-C3kx7_lZ.js";const V={free:3,free_linked:3,holder:15,scout:30,whale:999999,analyst:999999,syndicate:999999,og:999999,vip:999999},G=()=>{const[r,l]=m.useState([]),[n,o]=m.useState(""),[d,u]=m.useState(!1),[a,g]=m.useState("free"),[c,x]=m.useState(!1),[$,v]=m.useState(null),[s,y]=m.useState(null),[T]=m.useState(0),[S,P]=m.useState(null),A=m.useRef(null),R=V[a]||3;m.useEffect(()=>{chrome.storage.local.get(["tier","linked_telegram","auth_token"],e=>{g(e.tier||"free"),x(!!e.linked_telegram),v(e.auth_token||null),e.auth_token&&D(async()=>{const{getApiBase:p}=await import("./api-Cy855S04.js").then(k=>k.f);return{getApiBase:p}},[]).then(({getApiBase:p})=>{p().then(k=>{fetch(`${k}/ext/tier`,{headers:{Authorization:`Bearer ${e.auth_token}`}}).then(h=>h.ok?h.json():null).then(h=>{h!=null&&h.tier&&g(h.tier)}).catch(()=>{})})})}),chrome.storage.onChanged.addListener((e,p)=>{p==="local"&&e.tier&&g(e.tier.newValue||"free")}),l([{role:"marcus",content:"Welcome, fellow degen. I'm Marcus — your on-chain Stoic. Paste a contract address or ask me about any token on the current page. I'll give you the unfiltered truth. 🗿",timestamp:Date.now()}]),E()},[]),m.useEffect(()=>{var p,k;const e=()=>{chrome.tabs.query({active:!0,currentWindow:!0},h=>{var L;if((L=h[0])!=null&&L.url){const j=K(h[0].url);j&&j!==s&&(y(j),l(w=>[...w,{role:"system",content:`📍 Detected token: \`${j}\` — type "scan" to analyze it.`,timestamp:Date.now()}]))}})};return e(),(p=chrome.tabs.onActivated)==null||p.addListener(e),(k=chrome.tabs.onUpdated)==null||k.addListener((h,L)=>{L.url&&e()}),()=>{var h;(h=chrome.tabs.onActivated)==null||h.removeListener(e)}},[s]),m.useEffect(()=>{var e;(e=A.current)==null||e.scrollIntoView({behavior:"smooth"})},[r]);const C=m.useCallback((e,p,k)=>{l(h=>[...h,{role:e,content:p,timestamp:Date.now(),scanResult:k}])},[]),z=m.useCallback(async()=>{var j;const e=n.trim();if(!e||d)return;o(""),u(!0),C("user",e);const p=e.toLowerCase(),k=/^[A-Za-z0-9]{32,50}$/.test(e),h=p==="scan"||p.startsWith("scan "),L=k?e:h?e.split(" ")[1]||s:null;if(L){const w=await U(L);if(w.success&&w.data&&!w.data.not_scanned){const f=w.data;P(f);const M=f.risk_score,q=O(M),W=N(M);let _=`${q} **${f.token_symbol||"Unknown"}** — ${W} Risk (${M??"??"}/100)

`;_+=`**Price:** $${f.price_usd?F(f.price_usd):"—"}
`,_+=`**Market Cap:** ${b(f.market_cap)}
`,_+=`**Liquidity:** ${b(f.liquidity_usd)}
`,_+=`**Holders:** ${((j=f.holder_count)==null?void 0:j.toLocaleString())||"—"}
`,_+=`**Top 10%:** ${f.top_10_holder_percent?f.top_10_holder_percent.toFixed(1)+"%":"—"}
`,f.risk_factors&&f.risk_factors.length>0&&(_+=`
⚠️ **Risk Factors:**
`,f.risk_factors.forEach(I=>{_+=`• ${I}
`}));const B={critical:`
🚨 *"The obstacle is not the obstacle. The obstacle is your failure to walk away."*`,high:`
⚠️ *"Begin at once to live, and count each day as a separate life."* Proceed with extreme caution.`,moderate:`
🟡 Moderate risk. DYOR — not financial advice.`,low:`
🟢 Low risk indicators, but stay vigilant. No token is truly safe.`};if(M!=null){const I=M>=75?"critical":M>=50?"high":M>=25?"moderate":"low";_+=B[I]}C("marcus",_,f)}else C("marcus","❓ Couldn't analyze that token. It may not exist yet or the scan service timed out. Try the full scan via Telegram: @rug_munchy_bot")}else{const w=await Z(e,$,S,s,r.filter(f=>f.role!=="system").slice(-10));w?C("marcus",w):S?C("marcus",X(e,S)):C("marcus",ee(e,s,S))}u(!1)},[n,d,T,R,a,s,S,C]);return a!=="free"||!!c||!!$?i.jsxs("div",{style:{height:"100vh",backgroundColor:t.bg,color:t.textPrimary,fontFamily:"system-ui, -apple-system, sans-serif",display:"flex",flexDirection:"column"},children:[i.jsxs("div",{style:{padding:"10px 16px",borderBottom:`1px solid ${t.border}`,display:"flex",alignItems:"center",gap:8,flexShrink:0},children:[i.jsx("span",{style:{fontSize:18},children:"🗿"}),i.jsx("span",{style:{fontWeight:700,fontSize:14,color:t.gold},children:"Marcus"}),i.jsx("span",{style:{fontSize:9,padding:"2px 6px",borderRadius:8,backgroundColor:`${t.purple}20`,color:t.purpleLight,marginLeft:4},children:a}),i.jsxs("span",{style:{fontSize:10,color:t.textMuted,marginLeft:"auto"},children:[T,"/",R>=999999?"∞":R+"/day"]})]}),i.jsxs("div",{style:{flex:1,overflowY:"auto",padding:12,display:"flex",flexDirection:"column",gap:8},children:[r.map((e,p)=>i.jsx(J,{message:e},p)),d&&i.jsxs("div",{style:{padding:"8px 14px",borderRadius:12,backgroundColor:t.bgCard,color:t.textMuted,fontSize:12,alignSelf:"flex-start"},children:[i.jsx("span",{className:"pulse-anim",children:"Marcus is thinking..."}),i.jsx("style",{children:".pulse-anim { animation: pulse 1s infinite; } @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }"})]}),i.jsx("div",{ref:A})]}),s&&i.jsxs("div",{style:{padding:"4px 12px",margin:"0 12px 4px",backgroundColor:`${t.cyan}12`,borderRadius:6,border:`1px solid ${t.cyan}25`,fontSize:10,color:t.cyan,display:"flex",alignItems:"center",gap:6,flexShrink:0},children:[i.jsx("span",{children:"📍"}),i.jsx("span",{style:{fontFamily:"monospace",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:s}),i.jsx("button",{onClick:()=>{o("scan")},style:{background:"none",border:"none",color:t.cyan,fontSize:10,cursor:"pointer",fontWeight:600,flexShrink:0},children:"Scan →"})]}),i.jsxs("div",{style:{padding:"8px 12px",borderTop:`1px solid ${t.border}`,display:"flex",gap:8,flexShrink:0},children:[i.jsx("input",{type:"text",placeholder:"Paste CA or ask Marcus...",value:n,onChange:e=>o(e.target.value),onKeyDown:e=>e.key==="Enter"&&z(),style:{flex:1,padding:"10px 12px",backgroundColor:t.bgCard,border:`1px solid ${t.border}`,borderRadius:8,outline:"none",color:t.textPrimary,fontSize:12}}),i.jsx("button",{onClick:z,disabled:d||!n.trim(),style:{padding:"10px 16px",borderRadius:8,backgroundColor:d?t.border:t.purple,color:"#fff",border:"none",fontSize:14,fontWeight:600,cursor:d?"wait":"pointer",flexShrink:0},children:"→"})]})]}):i.jsxs("div",{style:{height:"100vh",backgroundColor:t.bg,color:t.textPrimary,fontFamily:"system-ui",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,textAlign:"center"},children:[i.jsx("div",{style:{fontSize:48,marginBottom:16},children:"🗿"}),i.jsx("h2",{style:{color:t.gold,marginBottom:8},children:"Marcus Chat"}),i.jsx("p",{style:{color:t.textSecondary,fontSize:13,marginBottom:20,maxWidth:280},children:"Sign in to unlock Marcus Chat. Link Telegram or use your Solana wallet."}),i.jsx("button",{onClick:()=>{var e,p;return(p=(e=chrome.runtime).openOptionsPage)==null?void 0:p.call(e)},style:{padding:"10px 20px",borderRadius:8,backgroundColor:t.purple,color:"#fff",border:"none",fontSize:13,fontWeight:600,cursor:"pointer"},children:"🔑 Sign In"}),i.jsx("p",{style:{color:t.textMuted,fontSize:10,marginTop:16},children:"Hold $CRM for 100 scans/hr and full access"})]})},J=({message:r})=>{const l=r.role==="user",n=r.role==="system";return i.jsxs("div",{style:{alignSelf:l?"flex-end":"flex-start",maxWidth:"88%"},children:[i.jsx("div",{style:{padding:"10px 14px",borderRadius:l?"14px 14px 2px 14px":"14px 14px 14px 2px",backgroundColor:n?`${t.cyan}10`:l?`${t.purple}25`:t.bgCard,border:`1px solid ${n?`${t.cyan}25`:l?`${t.purple}35`:t.border}`,fontSize:13,color:n?t.cyan:t.textPrimary,lineHeight:1.6,whiteSpace:"pre-wrap"},children:Y(r.content)}),i.jsx("div",{style:{fontSize:9,color:t.textMuted,marginTop:2,textAlign:l?"right":"left",padding:"0 4px"},children:new Date(r.timestamp).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})})]})};function Y(r){return r.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g).map((n,o)=>n.startsWith("**")&&n.endsWith("**")?i.jsx("strong",{children:n.slice(2,-2)},o):n.startsWith("*")&&n.endsWith("*")?i.jsx("em",{style:{color:t.textSecondary},children:n.slice(1,-1)},o):n.startsWith("`")&&n.endsWith("`")?i.jsx("code",{style:{fontFamily:"monospace",fontSize:11,backgroundColor:`${t.purple}15`,padding:"1px 5px",borderRadius:3,wordBreak:"break-all"},children:n.slice(1,-1)},o):i.jsx("span",{children:n},o))}function X(r,l){const n=r.toLowerCase(),o=l.risk_score??0,d=l.token_symbol||"this token",u=l.top_10_holder_percent||0,a=l.liquidity_usd||0,g=l.market_cap||0,c=l.holder_count||0,x=a>0?g/a:0,$=l.risk_factors||[];if(/trend|pattern|weird|suspicious|red.?flag|concern|issue|problem|smell|fishy|off|dodgy|strange/.test(n)){let s=`**Observations on ${d}:**

`;const y=[];if(u>50?y.push(`🚩 Top 10 control ${u.toFixed(1)}% — very concentrated`):u>30&&y.push(`⚠️ Top 10 hold ${u.toFixed(1)}% — moderate concentration`),a<1e4?y.push(`🚩 Liquidity only ${b(a)} — extremely thin`):a<5e4&&y.push(`⚠️ Liquidity ${b(a)} — watch for LP pulls`),x>50?y.push(`🚩 MCap/Liq ${x.toFixed(1)}x — massively overvalued`):x>20&&y.push(`⚠️ MCap/Liq ${x.toFixed(1)}x — stretched`),c<100?y.push(`🚩 Only ${c} holders`):c<500&&y.push(`⚠️ ${c} holders — still early`),$.forEach(T=>y.push(`⚠️ ${T}`)),y.length===0)s+=`Nothing immediately alarming. Ratio ${x.toFixed(1)}x, ${c.toLocaleString()} holders, top 10 at ${u.toFixed(1)}%.
But absence of red flags ≠ safe.`;else{y.forEach(S=>{s+=`${S}
`});const T=y.filter(S=>S.startsWith("🚩")).length;s+=`
${T>=2?"*Multiple red flags. I'd walk away.*":"*Some concerns. Set stop-losses.*"}`}return s+`

*"The impediment to action advances action."* 🗿`}if(/opinion|buy|ape|invest|worth|should|entry|good |bad /.test(n)){let s="";return o>=75?s=`At ${o}/100, this is a **hard no**. Multiple critical flags.`:o>=50?s=`Risk ${o}/100 — **high caution**. Not terrible but not reassuring.`:o>=25?s=`${o}/100 — moderate. Liq ${b(a)}, ${c.toLocaleString()} holders. ${u>40?"Concentration concerns me.":"Distribution okay."}`:s=`${o}/100 — relatively clean. Liq ${b(a)}, ${c.toLocaleString()} holders.`,`**My read on ${d}:**

${s}

*I give data, not financial advice.* 🗿`}if(/holder|whale|distribution|who|wallet|top/.test(n)){let s=`**${d} Holders:**

📊 Top 10: ${u.toFixed(1)}% | Total: ${c.toLocaleString()}

`;return u>50?s+="High concentration. Watch for coordinated selling.":u>30?s+="Moderate. Not ideal but not a deal-breaker.":s+="Well distributed. Organic growth territory.",s+`

Full bubblemap on Telegram @rug_munchy_bot 🗿`}if(/liq|pool|lp|depth|slip/.test(n)){let s=`**${d} Liquidity:**

💧 Pool: ${b(a)} | MCap/Liq: ${x.toFixed(1)}x

`;return a<5e3?s+="Dangerously thin.":a<25e3?s+="Thin. Slippage hurts on size.":a<1e5?s+="Acceptable for micro-cap.":s+="Decent depth.",x>30&&(s+=`

⚠️ Ratio ${x.toFixed(1)}x — stretched.`),s}if(/price|value|market.?cap|mcap|cost/.test(n))return`**${d} Valuation:**

💰 Price: $${l.price_usd?F(l.price_usd):"—"}
📊 MCap: ${b(g)}
💧 Liq: ${b(a)}
📐 Ratio: ${x.toFixed(1)}x`;let v=`**Re: ${d}** (risk ${o}/100)

`;return v+=`• Price: $${l.price_usd?F(l.price_usd):"—"} | MCap: ${b(g)}
`,v+=`• Liq: ${b(a)} (${x.toFixed(1)}x) | Holders: ${c.toLocaleString()}
`,v+=`• Top 10: ${u.toFixed(1)}%
`,$.length>0&&(v+=`
⚠️ ${$.slice(0,3).join(", ")}
`),v+=`
Ask about **trends**, **holders**, **liquidity**, or **should I buy**. 🗿`,v}async function Z(r,l,n,o,d){if(!l)return null;try{const u=await Q(),a={};o&&(a.mint=o),n&&(a.scan=n);const g=d.map($=>({role:$.role==="user"?"user":"marcus",content:$.content})),c=await fetch(`${u}/ext/chat`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${l}`},body:JSON.stringify({message:r,context:Object.keys(a).length>0?a:void 0,history:g.length>0?g:void 0})});return c.status===403?`🔒 Marcus chat requires **Holder** tier or above. Upgrade to unlock the full Marcus experience in the side panel.

*"The impediment to action advances action."* — Upgrade, citizen. 🗿`:c.status===429?`⏳ Daily Marcus chat limit reached. Even Stoics must rest.

*"The soul becomes dyed with the color of its thoughts."* Come back tomorrow. 🗿`:c.ok&&(await c.json()).response||null}catch{return null}}async function Q(){try{return(await chrome.storage.local.get("api_base")).api_base||"https://cryptorugmunch.ngrok.app/api"}catch{return"https://cryptorugmunch.ngrok.app/api"}}function ee(r,l,n){var d,u;const o=r.toLowerCase();if(o.includes("help")||o==="?")return`**What I can do:**

• **Paste a CA** — full risk scan with scores
• **"scan"** — analyze the token on current page
• Ask about **liquidity, holders, risks** on the last scanned token
• **"compare"** — context against known patterns

For the full Marcus experience (deep dives, bubblemaps, KOL intel, alpha), use @MarcusRugIntelBot on Telegram. 🗿`;if(o.includes("who")&&(o.includes("you")||o.includes("marcus")))return`I'm Marcus — Rug Munch Intelligence's on-chain analyst. Named after Marcus Aurelius, I embody Stoic principles in my analysis: seek truth, avoid emotional trading, accept the reality of risk.

Here I handle quick scans and analysis. On Telegram, I go deeper — full token forensics, holder bubblemaps, wallet DNA, KOL tracking, and real-time alerts.

*"The impediment to action advances action."* 🗿`;if(o.includes("rug")||o.includes("safe")||o.includes("legit")||o.includes("scam")){if(n){const a=n,g=a.risk_score??0;let c="";return g>=75?c="This looks like a strong avoid. Multiple red flags.":g>=50?c="Significant risk. I'd be very careful.":g>=25?c="Some concerns but not a clear rug setup.":c="Relatively clean indicators, but nothing is ever truly safe.",`Based on ${a.token_symbol||"the last scan"} (risk ${g}/100):

${c}

Key factors: Liq ${b(a.liquidity_usd)}, Top 10 at ${((d=a.top_10_holder_percent)==null?void 0:d.toFixed(1))||"?"}%, ${((u=a.holder_count)==null?void 0:u.toLocaleString())||"?"} holders.

*"It is not death that a man should fear, but never beginning to live."* Don't let fear stop you from good entries — but don't let greed blind you to rug signals.`}return`Scan a token first and I'll tell you what I see. Paste a CA or type **scan** on a token page.

*"The first rule of crypto: verify, don't trust."*`}return o.includes("how")&&(o.includes("work")||o.includes("score")||o.includes("risk"))?`**Risk Score (0-100):**

🟢 **0-24** Low risk
🟡 **25-49** Moderate — caution advised
🟠 **50-74** High — significant red flags
🔴 **75-100** Critical — likely scam/rug

**Factors analyzed:** liquidity depth, holder concentration, token age, freeze/mint authority, LP lock status, deployer history, buy/sell ratio, top holder behavior.

The full analysis on Telegram includes bubblemap visualization, wallet DNA profiling, and KOL activity tracking.`:l?`I see a token on this page. Type **scan** to get the full risk breakdown, or paste a different CA.

*"The happiness of your life depends upon the quality of your trades."* — Marcus, probably 🗿`:`Paste a contract address to scan, or navigate to a token page on DexScreener, Pump.fun, GMGN, Jupiter, BullX, Birdeye, Raydium, or Photon — I'll detect it automatically.

*"Waste no more time arguing about what a good token should be."* 🗿`}function F(r){return r===0?"0":r<1e-6?r.toExponential(2):r<.01?r.toFixed(8):r<1?r.toFixed(4):r.toFixed(2)}function b(r){return r?r>=1e6?`$${(r/1e6).toFixed(1)}M`:r>=1e3?`$${(r/1e3).toFixed(1)}K`:`$${r.toFixed(2)}`:"—"}H.createRoot(document.getElementById("root")).render(i.jsx(G,{}));
