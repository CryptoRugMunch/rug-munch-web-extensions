import{c as O,C as e,r as B,b as N}from"./analytics-DLXd4O_5.js";import{j as n}from"./jsx-runtime-D_zvdyIk.js";import{e as H,r as h,s as U}from"./api-DKPfphh3.js";import{e as K}from"./shadowInject-CoxC_aSk.js";const V={free:3,free_linked:3,holder:15,scout:30,whale:999999,analyst:999999,syndicate:999999,og:999999,vip:999999},G=()=>{const[r,l]=h.useState([]),[s,o]=h.useState(""),[d,u]=h.useState(!1),[i,f]=h.useState("free"),[c,y]=h.useState(!1),[$,w]=h.useState(null),[a,g]=h.useState(null),[C,T]=h.useState(0),[R,P]=h.useState(null),q=h.useRef(null),F=V[i]||3;h.useEffect(()=>{chrome.storage.local.get(["tier","linked_telegram","auth_token"],t=>{f(t.tier||"free"),y(!!t.linked_telegram),w(t.auth_token||null)}),chrome.storage.onChanged.addListener((t,m)=>{m==="local"&&t.tier&&f(t.tier.newValue||"free")}),l([{role:"marcus",content:"Welcome, fellow degen. I'm Marcus — your on-chain Stoic. Paste a contract address or ask me about any token on the current page. I'll give you the unfiltered truth. 🗿",timestamp:Date.now()}]),O()},[]),h.useEffect(()=>{var m,j;const t=()=>{chrome.tabs.query({active:!0,currentWindow:!0},k=>{var _;if((_=k[0])!=null&&_.url){const L=K(k[0].url);L&&L!==a&&(g(L),l(b=>[...b,{role:"system",content:`📍 Detected token: \`${L}\` — type "scan" to analyze it.`,timestamp:Date.now()}]))}})};return t(),(m=chrome.tabs.onActivated)==null||m.addListener(t),(j=chrome.tabs.onUpdated)==null||j.addListener((k,_)=>{_.url&&t()}),()=>{var k;(k=chrome.tabs.onActivated)==null||k.removeListener(t)}},[a]),h.useEffect(()=>{var t;(t=q.current)==null||t.scrollIntoView({behavior:"smooth"})},[r]);const v=h.useCallback((t,m,j)=>{l(k=>[...k,{role:t,content:m,timestamp:Date.now(),scanResult:j}])},[]),A=h.useCallback(async()=>{var L;const t=s.trim();if(!t||d)return;if(C>=F){v("system",`⏳ Rate limit reached (${F}/day for ${i} tier). ${i==="free"||i==="free_linked"?"Upgrade your tier for more scans.":"Take a breath — even Stoics rest."}`);return}o(""),u(!0),T(b=>b+1),v("user",t);const m=t.toLowerCase(),j=/^[A-Za-z0-9]{32,50}$/.test(t),k=m==="scan"||m.startsWith("scan "),_=j?t:k?t.split(" ")[1]||a:null;if(_){const b=await U(_);if(b.success&&b.data&&!b.data.not_scanned){const p=b.data;P(p);const M=p.risk_score,W=B(M),D=N(M);let S=`${W} **${p.token_symbol||"Unknown"}** — ${D} Risk (${M??"??"}/100)

`;S+=`**Price:** $${p.price_usd?z(p.price_usd):"—"}
`,S+=`**Market Cap:** ${x(p.market_cap)}
`,S+=`**Liquidity:** ${x(p.liquidity_usd)}
`,S+=`**Holders:** ${((L=p.holder_count)==null?void 0:L.toLocaleString())||"—"}
`,S+=`**Top 10%:** ${p.top_10_holder_percent?p.top_10_holder_percent.toFixed(1)+"%":"—"}
`,p.risk_factors&&p.risk_factors.length>0&&(S+=`
⚠️ **Risk Factors:**
`,p.risk_factors.forEach(I=>{S+=`• ${I}
`}));const E={critical:`
🚨 *"The obstacle is not the obstacle. The obstacle is your failure to walk away."*`,high:`
⚠️ *"Begin at once to live, and count each day as a separate life."* Proceed with extreme caution.`,moderate:`
🟡 Moderate risk. DYOR — not financial advice.`,low:`
🟢 Low risk indicators, but stay vigilant. No token is truly safe.`};if(M!=null){const I=M>=75?"critical":M>=50?"high":M>=25?"moderate":"low";S+=E[I]}v("marcus",S,p)}else v("marcus","❓ Couldn't analyze that token. It may not exist yet or the scan service timed out. Try the full scan via Telegram: @rug_munchy_bot")}else{const b=await Z(t,$,R,a,r.filter(p=>p.role!=="system").slice(-10));b?v("marcus",b):R?v("marcus",X(t,R)):v("marcus",ee(t,a,R))}u(!1)},[s,d,C,F,i,a,R,v]);return i!=="free"||!!c||!!$?n.jsxs("div",{style:{height:"100vh",backgroundColor:e.bg,color:e.textPrimary,fontFamily:"system-ui, -apple-system, sans-serif",display:"flex",flexDirection:"column"},children:[n.jsxs("div",{style:{padding:"10px 16px",borderBottom:`1px solid ${e.border}`,display:"flex",alignItems:"center",gap:8,flexShrink:0},children:[n.jsx("span",{style:{fontSize:18},children:"🗿"}),n.jsx("span",{style:{fontWeight:700,fontSize:14,color:e.gold},children:"Marcus"}),n.jsx("span",{style:{fontSize:9,padding:"2px 6px",borderRadius:8,backgroundColor:`${e.purple}20`,color:e.purpleLight,marginLeft:4},children:i}),n.jsxs("span",{style:{fontSize:10,color:e.textMuted,marginLeft:"auto"},children:[C,"/",F>=999999?"∞":F+"/day"]})]}),n.jsxs("div",{style:{flex:1,overflowY:"auto",padding:12,display:"flex",flexDirection:"column",gap:8},children:[r.map((t,m)=>n.jsx(J,{message:t},m)),d&&n.jsxs("div",{style:{padding:"8px 14px",borderRadius:12,backgroundColor:e.bgCard,color:e.textMuted,fontSize:12,alignSelf:"flex-start"},children:[n.jsx("span",{className:"pulse-anim",children:"Marcus is thinking..."}),n.jsx("style",{children:".pulse-anim { animation: pulse 1s infinite; } @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }"})]}),n.jsx("div",{ref:q})]}),a&&n.jsxs("div",{style:{padding:"4px 12px",margin:"0 12px 4px",backgroundColor:`${e.cyan}12`,borderRadius:6,border:`1px solid ${e.cyan}25`,fontSize:10,color:e.cyan,display:"flex",alignItems:"center",gap:6,flexShrink:0},children:[n.jsx("span",{children:"📍"}),n.jsx("span",{style:{fontFamily:"monospace",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:a}),n.jsx("button",{onClick:()=>{o("scan")},style:{background:"none",border:"none",color:e.cyan,fontSize:10,cursor:"pointer",fontWeight:600,flexShrink:0},children:"Scan →"})]}),n.jsxs("div",{style:{padding:"8px 12px",borderTop:`1px solid ${e.border}`,display:"flex",gap:8,flexShrink:0},children:[n.jsx("input",{type:"text",placeholder:"Paste CA or ask Marcus...",value:s,onChange:t=>o(t.target.value),onKeyDown:t=>t.key==="Enter"&&A(),style:{flex:1,padding:"10px 12px",backgroundColor:e.bgCard,border:`1px solid ${e.border}`,borderRadius:8,outline:"none",color:e.textPrimary,fontSize:12}}),n.jsx("button",{onClick:A,disabled:d||!s.trim(),style:{padding:"10px 16px",borderRadius:8,backgroundColor:d?e.border:e.purple,color:"#fff",border:"none",fontSize:14,fontWeight:600,cursor:d?"wait":"pointer",flexShrink:0},children:"→"})]})]}):n.jsxs("div",{style:{height:"100vh",backgroundColor:e.bg,color:e.textPrimary,fontFamily:"system-ui",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,textAlign:"center"},children:[n.jsx("div",{style:{fontSize:48,marginBottom:16},children:"🗿"}),n.jsx("h2",{style:{color:e.gold,marginBottom:8},children:"Marcus Chat"}),n.jsx("p",{style:{color:e.textSecondary,fontSize:13,marginBottom:20,maxWidth:280},children:"Sign in to unlock Marcus Chat. Link Telegram or use your Solana wallet."}),n.jsx("button",{onClick:()=>{var t,m;return(m=(t=chrome.runtime).openOptionsPage)==null?void 0:m.call(t)},style:{padding:"10px 20px",borderRadius:8,backgroundColor:e.purple,color:"#fff",border:"none",fontSize:13,fontWeight:600,cursor:"pointer"},children:"🔑 Sign In"}),n.jsx("p",{style:{color:e.textMuted,fontSize:10,marginTop:16},children:"Hold $CRM for 100 scans/hr and full access"})]})},J=({message:r})=>{const l=r.role==="user",s=r.role==="system";return n.jsxs("div",{style:{alignSelf:l?"flex-end":"flex-start",maxWidth:"88%"},children:[n.jsx("div",{style:{padding:"10px 14px",borderRadius:l?"14px 14px 2px 14px":"14px 14px 14px 2px",backgroundColor:s?`${e.cyan}10`:l?`${e.purple}25`:e.bgCard,border:`1px solid ${s?`${e.cyan}25`:l?`${e.purple}35`:e.border}`,fontSize:13,color:s?e.cyan:e.textPrimary,lineHeight:1.6,whiteSpace:"pre-wrap"},children:Y(r.content)}),n.jsx("div",{style:{fontSize:9,color:e.textMuted,marginTop:2,textAlign:l?"right":"left",padding:"0 4px"},children:new Date(r.timestamp).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})})]})};function Y(r){return r.split(/(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g).map((s,o)=>s.startsWith("**")&&s.endsWith("**")?n.jsx("strong",{children:s.slice(2,-2)},o):s.startsWith("*")&&s.endsWith("*")?n.jsx("em",{style:{color:e.textSecondary},children:s.slice(1,-1)},o):s.startsWith("`")&&s.endsWith("`")?n.jsx("code",{style:{fontFamily:"monospace",fontSize:11,backgroundColor:`${e.purple}15`,padding:"1px 5px",borderRadius:3,wordBreak:"break-all"},children:s.slice(1,-1)},o):n.jsx("span",{children:s},o))}function X(r,l){const s=r.toLowerCase(),o=l.risk_score??0,d=l.token_symbol||"this token",u=l.top_10_holder_percent||0,i=l.liquidity_usd||0,f=l.market_cap||0,c=l.holder_count||0,y=i>0?f/i:0,$=l.risk_factors||[];if(/trend|pattern|weird|suspicious|red.?flag|concern|issue|problem|smell|fishy|off|dodgy|strange/.test(s)){let a=`**Observations on ${d}:**

`;const g=[];if(u>50?g.push(`🚩 Top 10 control ${u.toFixed(1)}% — very concentrated`):u>30&&g.push(`⚠️ Top 10 hold ${u.toFixed(1)}% — moderate concentration`),i<1e4?g.push(`🚩 Liquidity only ${x(i)} — extremely thin`):i<5e4&&g.push(`⚠️ Liquidity ${x(i)} — watch for LP pulls`),y>50?g.push(`🚩 MCap/Liq ${y.toFixed(1)}x — massively overvalued`):y>20&&g.push(`⚠️ MCap/Liq ${y.toFixed(1)}x — stretched`),c<100?g.push(`🚩 Only ${c} holders`):c<500&&g.push(`⚠️ ${c} holders — still early`),$.forEach(C=>g.push(`⚠️ ${C}`)),g.length===0)a+=`Nothing immediately alarming. Ratio ${y.toFixed(1)}x, ${c.toLocaleString()} holders, top 10 at ${u.toFixed(1)}%.
But absence of red flags ≠ safe.`;else{g.forEach(T=>{a+=`${T}
`});const C=g.filter(T=>T.startsWith("🚩")).length;a+=`
${C>=2?"*Multiple red flags. I'd walk away.*":"*Some concerns. Set stop-losses.*"}`}return a+`

*"The impediment to action advances action."* 🗿`}if(/opinion|buy|ape|invest|worth|should|entry|good |bad /.test(s)){let a="";return o>=75?a=`At ${o}/100, this is a **hard no**. Multiple critical flags.`:o>=50?a=`Risk ${o}/100 — **high caution**. Not terrible but not reassuring.`:o>=25?a=`${o}/100 — moderate. Liq ${x(i)}, ${c.toLocaleString()} holders. ${u>40?"Concentration concerns me.":"Distribution okay."}`:a=`${o}/100 — relatively clean. Liq ${x(i)}, ${c.toLocaleString()} holders.`,`**My read on ${d}:**

${a}

*I give data, not financial advice.* 🗿`}if(/holder|whale|distribution|who|wallet|top/.test(s)){let a=`**${d} Holders:**

📊 Top 10: ${u.toFixed(1)}% | Total: ${c.toLocaleString()}

`;return u>50?a+="High concentration. Watch for coordinated selling.":u>30?a+="Moderate. Not ideal but not a deal-breaker.":a+="Well distributed. Organic growth territory.",a+`

Full bubblemap on Telegram @rug_munchy_bot 🗿`}if(/liq|pool|lp|depth|slip/.test(s)){let a=`**${d} Liquidity:**

💧 Pool: ${x(i)} | MCap/Liq: ${y.toFixed(1)}x

`;return i<5e3?a+="Dangerously thin.":i<25e3?a+="Thin. Slippage hurts on size.":i<1e5?a+="Acceptable for micro-cap.":a+="Decent depth.",y>30&&(a+=`

⚠️ Ratio ${y.toFixed(1)}x — stretched.`),a}if(/price|value|market.?cap|mcap|cost/.test(s))return`**${d} Valuation:**

💰 Price: $${l.price_usd?z(l.price_usd):"—"}
📊 MCap: ${x(f)}
💧 Liq: ${x(i)}
📐 Ratio: ${y.toFixed(1)}x`;let w=`**Re: ${d}** (risk ${o}/100)

`;return w+=`• Price: $${l.price_usd?z(l.price_usd):"—"} | MCap: ${x(f)}
`,w+=`• Liq: ${x(i)} (${y.toFixed(1)}x) | Holders: ${c.toLocaleString()}
`,w+=`• Top 10: ${u.toFixed(1)}%
`,$.length>0&&(w+=`
⚠️ ${$.slice(0,3).join(", ")}
`),w+=`
Ask about **trends**, **holders**, **liquidity**, or **should I buy**. 🗿`,w}async function Z(r,l,s,o,d){if(!l)return null;try{const u=await Q(),i={};o&&(i.mint=o),s&&(i.scan=s);const f=d.map($=>({role:$.role==="user"?"user":"marcus",content:$.content})),c=await fetch(`${u}/ext/chat`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${l}`},body:JSON.stringify({message:r,context:Object.keys(i).length>0?i:void 0,history:f.length>0?f:void 0})});return c.status===403?`🔒 Marcus chat requires **Holder** tier or above. Upgrade to unlock the full Marcus experience in the side panel.

*"The impediment to action advances action."* — Upgrade, citizen. 🗿`:c.status===429?`⏳ Daily Marcus chat limit reached. Even Stoics must rest.

*"The soul becomes dyed with the color of its thoughts."* Come back tomorrow. 🗿`:c.ok&&(await c.json()).response||null}catch{return null}}async function Q(){try{return(await chrome.storage.local.get("api_base")).api_base||"https://cryptorugmunch.ngrok.app/api"}catch{return"https://cryptorugmunch.ngrok.app/api"}}function ee(r,l,s){var d,u;const o=r.toLowerCase();if(o.includes("help")||o==="?")return`**What I can do:**

• **Paste a CA** — full risk scan with scores
• **"scan"** — analyze the token on current page
• Ask about **liquidity, holders, risks** on the last scanned token
• **"compare"** — context against known patterns

For the full Marcus experience (deep dives, bubblemaps, KOL intel, alpha), use @MarcusRugIntelBot on Telegram. 🗿`;if(o.includes("who")&&(o.includes("you")||o.includes("marcus")))return`I'm Marcus — Rug Munch Intelligence's on-chain analyst. Named after Marcus Aurelius, I embody Stoic principles in my analysis: seek truth, avoid emotional trading, accept the reality of risk.

Here I handle quick scans and analysis. On Telegram, I go deeper — full token forensics, holder bubblemaps, wallet DNA, KOL tracking, and real-time alerts.

*"The impediment to action advances action."* 🗿`;if(o.includes("rug")||o.includes("safe")||o.includes("legit")||o.includes("scam")){if(s){const i=s,f=i.risk_score??0;let c="";return f>=75?c="This looks like a strong avoid. Multiple red flags.":f>=50?c="Significant risk. I'd be very careful.":f>=25?c="Some concerns but not a clear rug setup.":c="Relatively clean indicators, but nothing is ever truly safe.",`Based on ${i.token_symbol||"the last scan"} (risk ${f}/100):

${c}

Key factors: Liq ${x(i.liquidity_usd)}, Top 10 at ${((d=i.top_10_holder_percent)==null?void 0:d.toFixed(1))||"?"}%, ${((u=i.holder_count)==null?void 0:u.toLocaleString())||"?"} holders.

*"It is not death that a man should fear, but never beginning to live."* Don't let fear stop you from good entries — but don't let greed blind you to rug signals.`}return`Scan a token first and I'll tell you what I see. Paste a CA or type **scan** on a token page.

*"The first rule of crypto: verify, don't trust."*`}return o.includes("how")&&(o.includes("work")||o.includes("score")||o.includes("risk"))?`**Risk Score (0-100):**

🟢 **0-24** Low risk
🟡 **25-49** Moderate — caution advised
🟠 **50-74** High — significant red flags
🔴 **75-100** Critical — likely scam/rug

**Factors analyzed:** liquidity depth, holder concentration, token age, freeze/mint authority, LP lock status, deployer history, buy/sell ratio, top holder behavior.

The full analysis on Telegram includes bubblemap visualization, wallet DNA profiling, and KOL activity tracking.`:l?`I see a token on this page. Type **scan** to get the full risk breakdown, or paste a different CA.

*"The happiness of your life depends upon the quality of your trades."* — Marcus, probably 🗿`:`Paste a contract address to scan, or navigate to a token page on DexScreener, Pump.fun, GMGN, Jupiter, BullX, Birdeye, Raydium, or Photon — I'll detect it automatically.

*"Waste no more time arguing about what a good token should be."* 🗿`}function z(r){return r===0?"0":r<1e-6?r.toExponential(2):r<.01?r.toFixed(8):r<1?r.toFixed(4):r.toFixed(2)}function x(r){return r?r>=1e6?`$${(r/1e6).toFixed(1)}M`:r>=1e3?`$${(r/1e3).toFixed(1)}K`:`$${r.toFixed(2)}`:"—"}H.createRoot(document.getElementById("root")).render(n.jsx(G,{}));
